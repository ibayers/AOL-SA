# Design System Strategy: The Serene Ledger

## 1. Overview & Creative North Star
The "Creative North Star" for this design system is **The Serene Ledger**. 

Most financial apps feel like spreadsheets—rigid, anxious, and cluttered. This system rejects the "tax software" aesthetic in favor of a high-end editorial experience. We achieve this through **Organic Minimalist Layering**: using depth, soft blurs, and generous white space to make complex financial data feel breathable and manageable. By utilizing asymmetric layouts (e.g., placing balance cards slightly off-center or overlapping header elements), we break the "template" look to create a signature, premium feel that builds user trust through intentionality.

---

## 2. Colors & Surface Architecture
Our palette transitions from the stability of Deep Teal to the lightness of Mint. We move beyond flat UI by treating the screen as a physical space.

### The Color Tokens
*   **Primary Hub:** `primary` (#006565) for core actions, transitioning to `primary_container` (#008080) for hero surfaces.
*   **The Semantic Scale:** `secondary` (#006c52) represents Income/Growth (Mint), while `tertiary` (#9a3b35) represents Expenses/Outflow (Coral).
*   **Neutral Ground:** `surface` (#f7f9fc) serves as our canvas.

### The "No-Line" Rule
**Explicit Instruction:** You are prohibited from using 1px solid borders for sectioning. High-end design is felt, not outlined. 
*   Define boundaries solely through background shifts. A `surface_container_low` card sitting on a `surface` background provides all the separation a user needs.
*   Use `surface_container_highest` only for the most critical interactive floating elements.

### Glass & Signature Textures
To achieve the requested "Glassmorphism," floating elements (like Bottom Navigation or Modals) must use `surface_container_lowest` at 80% opacity with a `20px` backdrop blur. 
*   **Signature Gradient:** For Hero sections, apply a linear gradient from `primary` to `primary_container` at a 135-degree angle. This adds a "visual soul" that flat hex codes cannot replicate.

---

## 3. Typography
We utilize a pairing of **Manrope** (Display/Headlines) for an authoritative, geometric feel and **Inter** (Body/Labels) for maximum legibility at small scales.

*   **Display-LG (Manrope, 3.5rem):** Reserved for the total net worth. It should feel like a statement, not just a number.
*   **Headline-MD (Manrope, 1.75rem):** Used for section titles. Use `on_surface_variant` to keep these prominent but calm.
*   **Title-SM (Inter, 1rem):** The workhorse for transaction names. Use `on_surface` for high contrast.
*   **Label-MD (Inter, 0.75rem):** For metadata (dates, categories). Always use `outline` color token to create a clear hierarchy.

---

## 4. Elevation & Depth: Tonal Layering
Traditional shadows are often "dirty." In this system, depth is achieved through **Tonal Stacking**.

*   **The Layering Principle:** Place a `surface_container_lowest` card (pure white) on a `surface_container_low` background. The contrast is enough to create a "lift" without a single drop shadow.
*   **Ambient Shadows:** If a card must float (e.g., a "Quick Add" button), use a shadow with a 24px blur, 0px offset, and 6% opacity. The shadow color must be a tinted version of `on_surface` (a deep navy-grey), never pure black.
*   **The "Ghost Border" Fallback:** If accessibility requires a border, use `outline_variant` at **15% opacity**. It should be a whisper, not a shout.
*   **Glassmorphism:** Use `surface_bright` with a 70% alpha for modal overlays to keep the user grounded in the context of the previous screen.

---

## 5. Components

### Cards & Lists
*   **Rule:** Forbid divider lines.
*   **Execution:** Separate transactions using `8px` (Spacing 2) of vertical white space. Group transactions by date using a `surface_container` background for the entire day-group, creating a "block" of activity rather than a list of lines.

### Buttons
*   **Primary:** High-pill shape (`rounded-full`). Use the Signature Gradient (`primary` to `primary_container`).
*   **Secondary/Glass:** `surface_container_highest` with a backdrop blur. These should feel like polished pebbles.
*   **Tertiary:** No background, `primary` text color, used for "See All" or "Cancel."

### Input Fields
*   **Visual Style:** Do not use boxes. Use a `surface_container_low` background with a `rounded-md` (0.75rem) corner. 
*   **Interaction:** Upon focus, the background shifts to `surface_container_highest`. Avoid high-contrast focus rings; use a subtle `2px` glow of `surface_tint`.

### Specialized Components
*   **The Trend Micro-Chart:** Small, sparkline-style charts integrated into category cards. Use `secondary` for positive trends and `tertiary` for over-budget warnings.
*   **Glass Bottom Dock:** A floating navigation bar using `surface_container_lowest` (80% opacity) with `rounded-xl` corners, positioned `20px` from the screen bottom.

---

## 6. Do's and Don'ts

### Do
*   **Do** use asymmetrical margins. A 24px left margin and 16px right margin on list items can make the app feel bespoke and editorial.
*   **Do** use `secondary_fixed` for "Income" badges—the muted tone is more sophisticated than a standard bright green.
*   **Do** embrace "Breathable Space." If in doubt, add more padding from the **Spacing Scale (8 or 10)**.

### Don't
*   **Don't** use pure black (#000000) for text. Always use `on_background` or `on_surface`.
*   **Don't** use standard "Material" shadows. If you can see the shadow clearly, it’s too dark.
*   **Don't** cram data. If a screen has more than 7-10 primary data points, use a "Nested" surface hierarchy to hide secondary details.
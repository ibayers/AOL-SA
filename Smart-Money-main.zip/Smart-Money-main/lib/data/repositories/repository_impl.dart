import 'package:supabase_flutter/supabase_flutter.dart';
import '../../domain/models/models.dart';
import '../../domain/repositories/repositories.dart';

/// Concrete Supabase implementation of [TransactionRepository].
class TransactionRepositoryImpl implements TransactionRepository {
  final SupabaseClient _client;
  TransactionRepositoryImpl(this._client);

  String get _userId => _client.auth.currentUser!.id;

  @override
  Future<List<TransactionModel>> getTransactions({DateTime? from, DateTime? to}) async {
    var query = _client
        .from('transactions')
        .select('*, categories(name, icon), payment_methods(name)')
        .eq('user_id', _userId);

    if (from != null) {
      query = query.gte('date', from.toIso8601String());
    }
    if (to != null) {
      query = query.lte('date', to.toIso8601String());
    }

    final data = await query.order('date', ascending: false);
    return data.map((json) => TransactionModel.fromJson(json)).toList();
  }

  @override
  Future<TransactionModel> addTransaction(TransactionModel txn) async {
    final data = await _client
        .from('transactions')
        .insert({...txn.toJson(), 'user_id': _userId})
        .select('*, categories(name, icon), payment_methods(name)')
        .single();
    return TransactionModel.fromJson(data);
  }

  @override
  Future<void> updateTransaction(TransactionModel txn) async {
    await _client
        .from('transactions')
        .update(txn.toJson())
        .eq('id', txn.id);
  }

  @override
  Future<void> deleteTransaction(String id) async {
    await _client.from('transactions').delete().eq('id', id);
  }
}

/// Concrete Supabase implementation of [CategoryRepository].
class CategoryRepositoryImpl implements CategoryRepository {
  final SupabaseClient _client;
  CategoryRepositoryImpl(this._client);

  String get _userId => _client.auth.currentUser!.id;

  @override
  Future<List<CategoryModel>> getCategories() async {
    final data = await _client
        .from('categories')
        .select()
        .eq('user_id', _userId)
        .order('created_at');
    return data.map((json) => CategoryModel.fromJson(json)).toList();
  }

  @override
  Future<CategoryModel> addCategory(CategoryModel category) async {
    final data = await _client
        .from('categories')
        .insert({...category.toJson(), 'user_id': _userId})
        .select()
        .single();
    return CategoryModel.fromJson(data);
  }

  @override
  Future<void> updateCategory(CategoryModel category) async {
    await _client
        .from('categories')
        .update(category.toJson())
        .eq('id', category.id);
  }

  @override
  Future<void> deleteCategory(String id) async {
    await _client.from('categories').delete().eq('id', id);
  }
}

/// Concrete Supabase implementation of [PaymentMethodRepository].
class PaymentMethodRepositoryImpl implements PaymentMethodRepository {
  final SupabaseClient _client;
  PaymentMethodRepositoryImpl(this._client);

  String get _userId => _client.auth.currentUser!.id;

  @override
  Future<List<PaymentMethodModel>> getPaymentMethods() async {
    final data = await _client
        .from('payment_methods')
        .select()
        .eq('user_id', _userId)
        .order('created_at');
    return data.map((json) => PaymentMethodModel.fromJson(json)).toList();
  }

  @override
  Future<PaymentMethodModel> addPaymentMethod(PaymentMethodModel method) async {
    final data = await _client
        .from('payment_methods')
        .insert({...method.toJson(), 'user_id': _userId})
        .select()
        .single();
    return PaymentMethodModel.fromJson(data);
  }

  @override
  Future<void> deletePaymentMethod(String id) async {
    await _client.from('payment_methods').delete().eq('id', id);
  }
}

/// Concrete Supabase implementation of [WishlistRepository].
class WishlistRepositoryImpl implements WishlistRepository {
  final SupabaseClient _client;
  WishlistRepositoryImpl(this._client);

  String get _userId => _client.auth.currentUser!.id;

  @override
  Future<List<WishlistItemModel>> getWishlistItems() async {
    final data = await _client
        .from('wishlist')
        .select()
        .eq('user_id', _userId)
        .order('created_at', ascending: false);
    return data.map((json) => WishlistItemModel.fromJson(json)).toList();
  }

  @override
  Future<WishlistItemModel> addWishlistItem(WishlistItemModel item) async {
    final data = await _client
        .from('wishlist')
        .insert({...item.toJson(), 'user_id': _userId})
        .select()
        .single();
    return WishlistItemModel.fromJson(data);
  }

  @override
  Future<void> updateWishlistItem(WishlistItemModel item) async {
    await _client
        .from('wishlist')
        .update(item.toJson())
        .eq('id', item.id);
  }

  @override
  Future<void> deleteWishlistItem(String id) async {
    await _client.from('wishlist').delete().eq('id', id);
  }

  @override
  Future<void> markAsCompleted(String id) async {
    await _client
        .from('wishlist')
        .update({'status': 'completed'})
        .eq('id', id);
  }
}

/// Concrete Supabase implementation of [ProfileRepository].
class ProfileRepositoryImpl implements ProfileRepository {
  final SupabaseClient _client;
  ProfileRepositoryImpl(this._client);

  String get _userId => _client.auth.currentUser!.id;

  @override
  Future<ProfileModel> getProfile() async {
    final data = await _client
        .from('profiles')
        .select()
        .eq('id', _userId)
        .single();
    // Attach email from auth user
    final email = _client.auth.currentUser?.email;
    return ProfileModel.fromJson({...data, 'email': email});
  }

  @override
  Future<void> updateProfile(ProfileModel profile) async {
    await _client
        .from('profiles')
        .update(profile.toJson())
        .eq('id', _userId);
  }

  @override
  Future<String> uploadAvatar(dynamic file, String fileName) async {
    final filePath = '$_userId/$fileName';
    await _client.storage.from('avatars').upload(
          filePath,
          file as dynamic, // Using dynamic to avoid hard dart:io dependency in repo contract if needed, but we'll cast it where called or we can use bytes. Actually let's just upload it.
          fileOptions: const FileOptions(cacheControl: '3600', upsert: true),
        );
    return _client.storage.from('avatars').getPublicUrl(filePath);
  }
}

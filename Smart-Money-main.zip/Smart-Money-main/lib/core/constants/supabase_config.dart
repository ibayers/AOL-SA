/// Supabase Configuration
///
/// Paste your Supabase Project URL and Anon Key below.
/// You can find these in: Supabase Dashboard → Settings → API
class SupabaseConfig {
  static const String url = 'https://ttidhbfodpalecrlafef.supabase.co';
  static const String anonKey =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR0aWRoYmZvZHBhbGVjcmxhZmVmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI1OTU1OTIsImV4cCI6MjA4ODE3MTU5Mn0.M7FEzXEazRLJiLMcwIaEKbBK30nOb0dTpS2ZQyW3Krg';
}
